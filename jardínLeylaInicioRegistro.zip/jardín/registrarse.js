function voltearTarjeta() {
  const caja = document.getElementById('cajaVolteable');
  caja.classList.toggle('volteado');
}